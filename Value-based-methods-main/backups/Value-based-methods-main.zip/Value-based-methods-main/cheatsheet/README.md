# Cheatsheet

You are encouraged to use the [PDF file](https://github.com/udacity/deep-reinforcement-learning/tree/master/cheatsheet/cheatsheet.pdf) in the repository to guide your study of RL.